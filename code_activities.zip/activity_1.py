def concatenate_uppercase_strings(str_a, str_b):
    return str_a.upper() + " " + str_b.upper()

print(concatenate_uppercase_strings("Hello", "World"))

